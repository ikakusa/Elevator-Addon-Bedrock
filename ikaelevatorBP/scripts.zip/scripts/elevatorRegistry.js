import * as server from "@minecraft/server";
import { ElevatorEntityBase } from "./elevator/elevatorBase";
import * as eUtils from "./elevatorUtils";
import { ElevatorSwitchEntity } from "./elevator/elevatorSwitchEntity";
import { ElevatorEntity } from "./elevator/elevatorEntity";

export class ElevatorRegistry {
    constructor() {
        /**
         * @type {Map<string, ElevatorEntityBase>}
         */
        this.maps = new Map();
        this.initialized = false;
    }

    /**
     * @param {server.Entity} entity
     */
    createInstance(entity) {
        if (!eUtils.ELEVATOR_IDS.includes(entity.typeId)) return undefined;
        if (!entity.typeId.startsWith(eUtils.ELEVATOR_BASE_ID)) return undefined;

        if (new RegExp(`${eUtils.ELEVATOR_BASE_ID}\\d+$`).test(entity.typeId)) { //elevator
            let frontIndex = [3, 5]; //basically type1 2x2 elevator
            switch (entity.typeId) {
                //今のところ追加はないです
                //2x2以外のエレベーターが出てきたら使うと思います
                default: break;
            }
            return new ElevatorEntity(entity, ...frontIndex);
        } else if (new RegExp(`${eUtils.ELEVATOR_BASE_ID}\\d+_switch$`).test(entity.typeId)) { //switch
            return new ElevatorSwitchEntity(entity);
        }
    }

    /**
     * 
     * @param {server.Entity} entity 
     */
    tryAdd(entity) {
        if (!this.maps.has(entity.id)) {
            const instance = this.createInstance(entity);
            if (instance) this.maps.set(entity.id, instance);
        }
    }

    /**
     * 
     * @param {server.Entity} entity 
     * @returns {ElevatorEntityBase | undefined}
     */
    tryGet(entity) {
        if (!entity) return;
        if (!entity.isValid) return;
        const value = this.maps.get(entity.id);
        if (!value || !value.entity.isValid) return undefined;
        return this.maps.get(entity.id);
    }

    removeInvalid() {
        for (const [id, instance] of this.maps) {
            if (!instance.entity.isValid) {
                this.maps.delete(id);
            }
        }
    }
}
import * as server from "@minecraft/server";
import * as eUtils from "../elevatorUtils";
import * as utils from "../utils";
import { ElevatorEntityBase } from "./elevatorBase";
import { Floors } from "./helper/floors";
import { Doors } from "./helper/doors";
import vec3 from "../vec3";

export class ElevatorEntity extends ElevatorEntityBase {
    /**
     * 
     * @param {server.Entity} entity 
     * @param {...number} frontCollisions 
     */
    constructor(entity, ...frontCollisions) {
        super(entity, eUtils.TYPES.ELEVATOR);

        this.getDoors();
        this.getFloors();
        this.getCallQueue();

        this.collisions = entity.getComponent("rideable")?.getRiders().length;
        this.frontCollisions = frontCollisions;
        this.speed = 0.115;
    }

    /**
     * @returns {boolean}
     */
    tick() {
        if (!this.entity.isValid) return false;
        const elevator = this.entity;
        const available = this.canMove();
        const opened = this.isDoorOpen();
        const open_timer = this.getOpenTimer();

        if (opened && Date.now() - open_timer > 7000) {
            this.toggleDoor();
        }

        if (Date.now() - open_timer < 9250) return true;

        this.setCanMove(true);
        this.setArriveFloor(false);

        const q = this.callQueue;
        if (q.isEmpty() || !available) return true;
        this.setIsMoving(true);
        const currentY = elevator.location.y;
        const currentQ = q.floors[0];
        const diffY = currentY - currentQ;
        const isUp = diffY < 0;

        const aabb = elevator.getAABB();
        const center = aabb.center;
        const size = aabb.extent;
        const loc = elevator.location;
        const boxMin = new vec3(center.x - size.x, center.y - size.y - ((loc.y + this.speed) - loc.y), center.z - size.z);
        const boxMax = new vec3(center.x + size.x, center.y + size.y + ((loc.y + this.speed) - loc.y), center.z + size.z);
        const players = elevator.dimension.getPlayers().filter(player => vec3.from(player.location).isInRange(boxMin, boxMax));

        if (Math.abs(diffY) <= this.speed) { //ついた
            players.forEach(player => {
                player.clearVelocity();
                player.applyImpulse({ x: 0, y: ((loc.y + this.speed) - loc.y) * 2, z: 0 });
            });
            elevator.teleport({ x: loc.x, y: currentQ, z: loc.z });

            this.entity.dimension.playSound("note.bell", this.entity.location);
            if (!opened)
                this.openDoor();
            this.setArriveTimer(Date.now());

            /**
             * @type {number[]}
             */
            let floors = this.floors.floors;
            const currentFloor = floors.indexOf(currentQ);

            const checkDoor = () => {
                if (currentFloor !== -1) {
                    const doors = this.doors.doors;
                    const door = doors[currentFloor];
                    if (!door) return;
                    const doorEnt = server.world.getEntity(door);
                    if (!doorEnt) return;
                    const doorOpen = utils.getProperty(doorEnt, "open", false);
                    if (!doorOpen) this.openDoor(doorEnt, doorEnt.getComponent("rideable")?.getRiders());
                }
            };
            checkDoor();

            this.setLastOpen(currentFloor);

            this.popQueue();

            this.setCanMove(false);
            this.setArriveFloor(true);
            this.setIsMoving(false);

            return true;
        }

        if (!this.canMove() || this.arriveFloor() || !this.isMoving()) return true;

        if (isUp) {
            players.forEach(player => {
                player.clearVelocity();
                player.applyImpulse({ x: 0, y: ((loc.y + this.speed) - loc.y) * (1 + (this.speed * 1.15)), z: 0 });
                if (player.location.y < center.y) {
                    player.teleport({
                        x: player.location.x,
                        y: loc.y + this.speed + 1,
                        z: player.location.z
                    });
                }
            });
            elevator.teleport({ x: loc.x, y: loc.y + this.speed, z: loc.z });
        } else {
            elevator.teleport({ x: loc.x, y: loc.y - this.speed, z: loc.z });
        }
        return true;
    }

    /** @returns {boolean}*/      isMoving() { return utils.getProperty(this.entity, "moving", false); }
    /** @returns {boolean} */     canMove() { return utils.getProperty(this.entity, "can_move", true); }
    /** @returns {boolean} */     arriveFloor() { return utils.getProperty(this.entity, "arrive_floor", false); }

    /** @returns {number} */      getOpenTimer() { return utils.getProperty(this.entity, "open_timer", 0); }
    /** @returns {number} */      getArriveTimer() { return utils.getProperty(this.entity, "arrive_timer", 0); }

    /**@param {boolean} value  */ setCanMove(value) { this.entity.setDynamicProperty("can_move", value) }
    /**@param {boolean} value  */ setIsMoving(value) { this.entity.setDynamicProperty("moving", value) }
    /** @param {boolean} value  */setArriveFloor(value) { this.entity.setDynamicProperty("arrive_floor", value) }

    /** @param {number} value  */ setArriveTimer(value) { this.entity.setDynamicProperty("arrive_timer", value) }
    /** @param {number} value  */ setOpenTimer(value) { this.entity.setDynamicProperty("open_timer", value) }
    /** @param {number} value  */ setArriveTimer(value) { this.entity.setDynamicProperty("arrive_timer", value) }

    /**
     * for initialize
     * @returns {Floors} //floors
     */
    getCallQueue() {
        this.callQueue = new Floors(JSON.parse(utils.getProperty(this.entity, "call_queue", "[]")));
        return this.callQueue;
    }

    saveCallQueue() {
        this.entity.setDynamicProperty("call_queue", JSON.stringify(this.callQueue.floors));
    }

    /**
     * 
     * @param {number} floor index 
     * @returns {boolean}
     */
    addQueue(floor) {
        const result = this.callQueue.add(floor);
        if (result) this.saveCallQueue();
        return result;
    }

    popQueue() {
        this.callQueue.remove(0);
        this.saveCallQueue();
    }

    /**
     * for initialize
     * @returns {Doors}
     */
    getDoors() {
        this.doors = new Doors(JSON.parse(utils.getProperty(this.entity, "elevator_doors", "{}")));
        return this.doors;
    }

    saveDoors() {
        this.entity.setDynamicProperty("elevator_doors", JSON.stringify(this.doors.doors));
    }

    /**
     * 
     * @param {number} index 
     * @param {string} doorEntityId 
     */
    addDoor(index, doorEntityId) {
        this.doors.update(index, doorEntityId);
        this.saveDoors();
    }

    /**
     * 
     * @param {number} index 
     */
    removeDoor(index) {
        this.doors.remove(index);
        this.saveDoors();
    }

    /**
     * for initialize
     * @returns {Floors}
     */
    getFloors() {
        this.floors = new Floors(JSON.parse(utils.getProperty(this.entity, "floors", "[]")));
        return this.floors;
    }

    saveFloors() {
        this.entity.setDynamicProperty("floors", JSON.stringify(this.floors.floors));
    }

    /**
     * 
     * @param {number} floorY y location 
     * @returns {boolean}
     */
    addFloor(floorY) {
        const result = this.floors.add(floorY);
        if (result) this.saveFloors();
        return result;
    }

    /**
     * 
     * @param {number} index starts 0 
     */
    removeFloor(index) {
        this.floors.remove(index);
        this.saveFloors();
    }

    /**
     * @returns {boolean}
     */
    isDoorOpen() {
        return utils.getProperty(this.entity, "open", false);
    }

    /**
     * @returns {number}
     */
    getLastOpen() {
        return utils.getProperty(this.entity, "last_open_floor", -1);
    }

    /**
     * 
     * @param {number} floor 
     */
    setLastOpen(floor) {
        this.entity.setDynamicProperty("last_open_floor", floor);
    }

    /**
     * @param {boolean} [all=false] returns all
     * @returns {server.Entity[]}
     */
    getFrontCollisions() {
        if (!this.entity.isValid) return;
        const rideable = this.entity.getComponent("rideable");
        return rideable?.getRiders().slice(this.frontCollisions[0], this.frontCollisions[1]);
    }

    /**
     * 
     * @param {server.Entity | null} other 
     * @param {server.Entity[]} [otherCollisions=null] 
     */
    openDoor(other = null, otherCollisions = null) {
        server.system.run(() => {
            const use = other ? other : this.entity;
            if (!use.isValid) return;
            const collisions = otherCollisions ? otherCollisions : this.getFrontCollisions();
            if (!collisions) return;
            collisions.forEach(c => c.triggerEvent("elevator_collision:no_collidable"));

            use.setDynamicProperty("open", true);
            use.setProperty("property:open", true);
            use.setDynamicProperty("open_timer", Date.now());
        });
    }
    /**
     * 
     * @param {server.Entity | null} other 
     * @param {server.Entity[]} [otherCollisions=null] 
     */
    closeDoor(other = null, otherCollisions = null) {
        server.system.run(() => {
            const use = other ? other : this.entity;
            if (!use.isValid) return;
            const collisions = otherCollisions ? otherCollisions : this.getFrontCollisions();
            if (!collisions) return;
            collisions.forEach(c => c.triggerEvent("elevator_collision:collidable"));

            use.setDynamicProperty("open", false);
            use.setProperty("property:open", false);
            use.setDynamicProperty("open_timer", Date.now());
        });
    }

    /**
     * @param {number} milliseconds 
     */
    earlyOpenTimer(milliseconds, other = null) {
        const use = other ? other : this.entity;
        const current = utils.getProperty(use, "open_timer", 0);
        use.setDynamicProperty("open_timer", current - milliseconds);
    }

    /**
     * 
     * @param {server.Player} player 
     */
    isPlayerInside(player) {
        const aabb = this.entity.getAABB();
        const center = aabb.center;
        const size = aabb.extent;
        const loc = this.entity.location;
        const boxMin = new vec3(center.x - size.x, center.y - size.y, center.z - size.z);
        const boxMax = new vec3(center.x + size.x, center.y + size.y + ((loc.y + this.speed) - loc.y), center.z + size.z);
        const players = this.entity.dimension.getPlayers().filter(player => vec3.from(player.location).isInRange(boxMin, boxMax));
        return players.includes(player);
    }

    /**
     * @param {server.Player} player 
     * @param {boolean} insideCheck checks player is inside of the elevator 
     */
    toggleDoor(player = null, insideCheck = false) {
        if (!this.entity.isValid) return;
        let pass = !insideCheck;
        if (insideCheck) {
            pass = this.isPlayerInside(player) && !utils.getProperty(this.entity, "moving", false) && player.isSneaking;
        }

        if (pass) {
            const opened = this.isDoorOpen();
            if (!opened)
                this.openDoor();
            else
                this.closeDoor();

            //parent door
            const last_open = this.getLastOpen();
            if (last_open === -1) return;
            const door = this.doors.doors[last_open];
            if (!door) return;
            const doorEnt = server.world.getEntity(door);
            if (!doorEnt) return;
            const colls = doorEnt.getComponent("rideable")?.getRiders();
            const doorOpen = utils.getProperty(doorEnt, "open", false);
            if (!doorOpen) this.openDoor(doorEnt, colls);
            else this.closeDoor(doorEnt, colls);
        }
    }
}
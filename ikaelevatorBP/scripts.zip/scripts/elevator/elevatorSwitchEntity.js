import * as server from "@minecraft/server";
import * as eUtils from "../elevatorUtils";
import { ElevatorEntityBase } from "./elevatorBase";

export class ElevatorSwitchEntity extends ElevatorEntityBase {
    /**
     * 
     * @param {server.Entity} entity 
     */
    constructor(entity) {
        super(entity, eUtils.TYPES.ELEVATOR_SWITCH);
        /**
         * @type {number}
         */
        this.floor = -1;
        /**
         * @type {string | undefined}
         * entity unique id
         */
        this.elevator = undefined;
    }
}
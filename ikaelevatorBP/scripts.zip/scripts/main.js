import * as server from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import vec3 from "./vec3.js";
import * as utils from "./utils.js";
import * as Elevator from "./elevatorUtils.js";
import { ElevatorRegistry } from "./elevatorRegistry.js";
import { ElevatorEntity } from "./elevator/elevatorEntity.js";
import { ElevatorSwitchEntity } from "./elevator/elevatorSwitchEntity.js";

const Elevators = new ElevatorRegistry();

server.world.afterEvents.entityLoad.subscribe(ev => {
    Elevators.tryAdd(ev.entity);
});

server.world.afterEvents.entitySpawn.subscribe(ev => {
    Elevators.tryAdd(ev.entity);
});

// retrieve elevatoe entts
server.system.run(() => {
    for (const dimId of ["overworld", "nether", "the_end"]) {
        //ドア以外のエンティティ
        const entities = server.world.getDimension(dimId).getEntities().filter(ent => Elevator.ELEVATOR_IDS.filter(el => !el.includes("_door")).includes(ent.typeId));
        for (const entity of entities) {
            Elevators.tryAdd(entity);
        }
    }
    Elevators.initialized = true;
});

server.system.runInterval(() => {
    if (Elevators.initialized) Elevators.removeInvalid();
});

server.world.beforeEvents.playerInteractWithEntity.subscribe(ev => {
    const player = ev.player;
    const item = ev.itemStack;
    const entity = ev.target;
    if (Elevator.isManageItem(item) && Elevator.orCollision(entity, Elevator.TYPES.ELEVATOR_DOOR)) {
        const ent = Elevator.getMount(entity);
        if (Elevator.is(ent, Elevator.TYPES.ELEVATOR_DOOR)) {
            if (player.isSneaking) {
                server.system.run(() => {
                    const menu = new ui.MessageFormData();
                    menu.title("確認")
                    menu.body("扉を撤去しますか？");
                    menu.button1("はい");
                    menu.button2("いいえ");
                    menu.show(player).then(res => {
                        if (res.canceled || res.selection === 1) return;
                        Elevator.removeElevator(ent);
                    });
                });
                return;
            }
            player.setDynamicProperty("pending_elevator_door_id", ent.id);
            player.sendMessage("管理用アイテムを持ってエレベーターを右クリックして紐づけ");
            return;
        }
    }

    if (Elevator.orCollision(entity, Elevator.TYPES.ELEVATOR)) {
        const ent = Elevator.getMount(entity);
        /**
         * @type {ElevatorEntity}
         */
        const instance = Elevators.tryGet(ent);
        if (!instance || !instance.isElevator()) return;
        if (Elevator.isManageItem(item)) { //管理
            const pending = player.getDynamicProperty("pending_elevator_door_id");
            if (pending) {
                let floors = instance.floors;
                if (floors.isEmpty()) {
                    player.sendMessage("先に階層を設定する必要があります");
                    player.setDynamicProperty("pending_elevator_door_id", undefined);
                    return;
                }
                const menu = new ui.ModalFormData();
                menu.title("紐づけ");
                menu.label("階層を入力");
                menu.textField("階層", "数字を入れてください (例: 1)");
                server.system.run(() => {
                    menu.show(player).then(res => {
                        if (res.canceled) {
                            player.setDynamicProperty("pending_elevator_door_id", undefined);
                            return;
                        }
                        let value = parseInt(res.formValues[1]);
                        if (isNaN(value)) {
                            player.sendMessage("階層は数値である必要があります");
                            return;
                        }
                        value = Math.max(1, Math.min(floors.floors.length, value));
                        instance.addDoor(value - 1, pending);
                    });
                });
                player.setDynamicProperty("pending_elevator_door_id", undefined);
                return;
            }
            server.world.sendMessage(ent.id);
            const showMenu = () => {
                const menu = new ui.ActionFormData();
                menu.title("エレベーターの管理");
                menu.button("90度回転"); // 0
                menu.button("階層の一覧"); // 1
                menu.button("階層の追加"); // 2
                menu.button("階層の削除"); // 3
                menu.button("詰まり解消"); // 4
                menu.button("エレベーター本体を削除"); // 4
                server.system.run(() => {
                    menu.show(player).then(res => {
                        if (res.canceled) return;
                        let floors = instance.getFloors(); //y座標のリスト
                        switch (res.selection) {
                            case 0: { //90度回転
                                ent.setRotation({ x: ent.getRotation().x, y: ent.getRotation().y + 90 });
                            } break;
                            case 1: { //リスト
                                const floorMenu = new ui.MessageFormData();
                                floorMenu.title(`階層リスト (${floors.length ?? 0}階層)`);
                                floorMenu.body(`${floors.floors.map((floor, i) => `${i + 1}階: Y${floor} ${ent.location.y === floor ? "<-- 今の階層" : ""}`).join("\n")}`);
                                floorMenu.button1("戻る");
                                floorMenu.button2("戻る");
                                floorMenu.show(player).then(res => {
                                    return showMenu();
                                });
                            } break;
                            case 2: { //追加
                                const addMenu = new ui.ModalFormData();
                                addMenu.title("階層の追加");
                                addMenu.label("エレベーターの土台を基準とした高さにしてください");
                                addMenu.textField("Y座標", "y座標を入力 (例: 64)");
                                addMenu.show(player).then(res => {
                                    if (res.canceled) return showMenu();
                                    let value = parseInt(res.formValues[1]);
                                    const range = player.dimension.heightRange;
                                    if (isNaN(value)) {
                                        player.sendMessage(`${range.min} ~ ${range.max} の範囲で入力してください`);
                                        showMenu();
                                        return;
                                    }

                                    value = Math.min(range.max, Math.max(range.min, value));
                                    if (!instance.addFloor(value)) {
                                        player.sendMessage("既に存在します");
                                        showMenu();
                                    }
                                });
                            } break;
                            case 3: { //階層を削除
                                const removeMenu = new ui.ModalFormData();
                                removeMenu.title("階層の削除");
                                removeMenu.label("エレベーターの階層を入力してください");
                                removeMenu.textField("階層", "階層を入力 (例: 2)");
                                removeMenu.show(player).then(res => {
                                    if (res.canceled) return showMenu();
                                    let value = parseInt(res.formValues[1]);
                                    if (isNaN(value)) {
                                        player.sendMessage(`階層を入力してください`);
                                        showMenu();
                                        return;
                                    }

                                    instance.removeFloor(value - 1);
                                    return showMenu();
                                });
                            } break;
                            case 4: {
                                instance.setArriveTimer(0);
                                instance.setArriveFloor(false);
                                instance.setCanMove(true);
                                instance.setIsMoving(false);
                                instance.callQueue.floors = [];
                                instance.setOpenTimer(0);
                            } break;
                            case 5: { //削除
                                instance.die();
                            } break;
                            default:
                                break;
                        }
                    });
                });
            };
            showMenu();
            return;
        }

        //open and close
        if (instance.isPlayerInside(player) && !utils.getProperty(ent, "moving", false) && player.isSneaking) {
            instance.toggleDoor(player, true);
            instance.earlyOpenTimer(3000);
        }
    }
});

server.world.beforeEvents.entityHurt.subscribe(ev => {
    if (ev.hurtEntity.typeId.includes("elevator:") && ev.damageSource.cause !== server.EntityDamageCause.selfDestruct) {
        ev.cancel = true;
        return;
    }
});

server.world.beforeEvents.playerInteractWithBlock.subscribe(ev => {
    const item = ev.itemStack;
    const player = ev.player;
    const block = ev.block;
    const first = ev.isFirstEvent;
    if (!first) return;

    if (block.typeId.includes("_sign")) {
        const sign = block.getComponent("sign");
        if (!sign || !sign.isWaxed) return;
        if (item && item.typeId.includes("_axe") && player.getGameMode() === server.GameMode.Creative) {
            server.system.run(() => {
                sign.setWaxed(false);
            });
        }
        ev.cancel = true;
        const signTexts = sign.getText(server.SignSide.Front).split("\n").slice(4);
        const floorNum = parseInt(signTexts[0]);
        if (isNaN(floorNum)) return;
        const id = signTexts[1];
        const elevator = player.dimension.getEntities().filter(ent => ent.id === id)[0];
        if (!elevator) return;
        /**
         * @type {ElevatorEntity}
         */
        const instance = Elevators.tryGet(elevator);
        if (!instance) return;
        const floors = instance.getFloors();
        const floor = floors.at(floorNum - 1);
        if (!floor) return;
        let queue = instance.callQueue.floors;
        if (elevator.location.y !== floor && !queue.includes(floor)) { //do IT
            instance.addQueue(floor);
        } else if (elevator.location.y === floor && !instance.isMoving()) {
            instance.setLastOpen(floorNum - 1);
            instance.toggleDoor(player);
            instance.earlyOpenTimer(3000);
        }
    }
});

server.world.afterEvents.worldLoad.subscribe(() => {
    server.system.runInterval(() => {
        for (const [id, inst] of Elevators.maps) {
            if (!inst.isElevator()) continue;
            /**
             * @type {ElevatorEntity}
             */
            const instance = inst;
            instance.tick();
        }
    });
});
